import pandas as pd
import logging
import numpy as np
import sys
import matplotlib.pyplot as plt
from sklearn.cross_validation import train_test_split
from sklearn.metrics.pairwise import euclidean_distances

#######################################
####Q1: Normalization
"""
Normalize the data, standardize all the data to [0, 1]
remember test data is standardized by statistics computed from training data
Your function should take both train and test feature vector as input,
and output both after normalization
TODO
"""
def feature_normalization(train, test):
    #TODO
    return train, test
    
########################################
####Q2: The loss function
"""
Given a set of X, y, theta
return the loss amount defined by loss function
TODO
"""
def compute_cost(X, y, theta):
    loss = 0
    #TODO
    return loss


########################################
###Q3: batch gradient descent
"""
In the question you will implement batch gradient descent
Given X, y, step_size: alpha, iterations number: num_iter
return theta: the optimal parameters learnt.
TODO
"""
def batch_grad_descent(X, y, alpha=0.1, num_iter=100, watch_list=None):
    num_instances, num_feature = X.shape[0], X.shape[1]
    theta = np.ones(num_feature)
    #TODO
    return theta
    
###########################################
###Q4: Gradient Checker
#In gradient descent, you should make sure the gradient computed is correct
#Here we approximate theta using (J(theta+epsilon) - J(theta-epsilon))/(2*epsilon)
#http://ufldl.stanford.edu/wiki/index.php/Gradient_checking_and_advanced_optimization
"""
Implement Gradient Checker
Prove that function batch_grad_descent's output grad is correct in each turn
"""
def grad_checker(X, y, grad, theta, epsilon=1): 
    #initialize guess
    guess = np.zeros(theta.shape[0])
    
    #TODO


###################################################
###Q5: Bath Gradient Descent with regularization term
"""
Implement regularized gradient descent
Input: X, y, step_size: alpha, regularization coefficient: lambda, iteration number: num_iter
Output: theta: the pars learnt 
"""
def regularized_grad_descent(X, y, alpha=0.1, lamda=1, num_iter=100, watch_list=None):
    num_instances, num_feature = X.shape[0], X.shape[1]
    theta = np.ones(num_feature)
    #TODO
    return theta

#############################################
###Q6: Stochastic Gradient Descent
"""
In the question you will implement stochastic gradient descent with regularization term
Given X, y, step_size: alpha, iterations number: num_iter
return theta: the optimal parameters learnt.
TODO
"""
def stochastic_grad_descent(X, y, alpha=0.1, lamda=1, num_iter=100, watch_list=None):
    num_instances, num_feature = X.shape[0], X.shape[1]
    theta = np.ones(num_feature)
    #TODO
    return theta

    
#################################################
##Q7: SGD with adaptive learning rate
#In SGD mostly we should use adaptive learning rate to increase convergence speed





#Loading the dataset
df = pd.read_csv('winequality-white-2.csv', delimiter=';')
X = df.values[:,:-1]
#add bias column
X = np.hstack((X, np.zeros((X.shape[0], 1))))
y = df.values[:,-1]
logging.info('loading the dataset')

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 2000)
logging.info('Split into Train and Test')
X_train, X_test = feature_normalization(X_train, X_test)

batch_grad_descent(X_train, y_train, alpha=0.2, num_iter=100, watch_list=(X_test, y_test))
regularized_grad_descent(X_train, y_train, alpha=0.2, lamda=100, num_iter=100, watch_list=(X_test, y_test))
stochastic_grad_descent(X_train, y_train, alpha=0.01, lamda=0.01, num_iter=1, watch_list=(X_test, y_test))